//package com.springbook.repository.book;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.springbook.entity.book.StockEntity;
//
//public interface StockRepository extends JpaRepository<StockEntity, Long> {
//	StockEntity findByBookId(Long bookid);
//}
